--
-- PostgreSQL database dump
--

\restrict hmuxOHlxOxJlCyNc28QWvkj0Z8osCfehDbtRPi8RwR5ekQzOSlEcSLaTk607aWY

-- Dumped from database version 16.14 (Ubuntu 16.14-1.pgdg24.04+1)
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- PostgreSQL database dump complete
--

\unrestrict hmuxOHlxOxJlCyNc28QWvkj0Z8osCfehDbtRPi8RwR5ekQzOSlEcSLaTk607aWY

